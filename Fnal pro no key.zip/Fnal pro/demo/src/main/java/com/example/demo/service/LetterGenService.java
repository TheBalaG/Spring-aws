package com.example.demo.service;

import com.example.demo.entityty.PolicyDetails;
import org.springframework.stereotype.Service;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.StringTemplateResolver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;


import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.xhtmlrenderer.pdf.ITextRenderer;
import com.lowagie.text.DocumentException;
import org.apache.pdfbox.io.IOUtils;
import java.util.Base64;


import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;
import software.amazon.awssdk.services.s3.model.S3Object;
import software.amazon.awssdk.core.sync.*;
import software.amazon.awssdk.core.exception.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import software.amazon.awssdk.core.ResponseInputStream;

import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import java.io.ByteArrayInputStream;

@Service
public class LetterGenService 
{    
	
	 @Autowired
	 private S3Client amazonS3Client;

	@Value("${aws.s3.bucket}")
	private String bucketName;
    
	private String s="Starting";
	

    public byte[] generatePDF(PolicyDetails policyDetails) throws IOException, DocumentException {
        String policyNo = policyDetails.getPolicyno();
        String html = parseThymeleafTemplate(policyDetails);

        try {
            return generatePdfFromHtml(html, policyNo);
        } catch (Exception e) {
            System.out.println("Exception error: " + e.getMessage());
            throw e;
        }
    }


	
    private String fetchTemplateFromS3(String templateKey) throws IOException {
        try {
            // Fetch the object from S3
            GetObjectRequest getObjectRequest = GetObjectRequest.builder().bucket(bucketName).key(templateKey).build();
            ResponseInputStream<GetObjectResponse> objectData = amazonS3Client.getObject(getObjectRequest);

            // Get the content of the object
            InputStream objectDataStream = objectData;
            InputStreamReader streamReader = new InputStreamReader(objectDataStream);
            BufferedReader reader = new BufferedReader(streamReader);

            // Read the content of the file into a StringBuilder
            StringBuilder content = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line);
            }

            // Close the resources
            reader.close();
            streamReader.close();
            objectDataStream.close();

            return content.toString();
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } 
    }

    private String fetchImageFromS3(String imageKey) {
        try {
            GetObjectRequest getObjectRequest = GetObjectRequest.builder().bucket(bucketName).key(imageKey).build();
            ResponseInputStream<GetObjectResponse> objectData = amazonS3Client.getObject(getObjectRequest);

            // Get the content of the object
            InputStream objectDataStream = objectData;
            
            // Convert InputStream to Base64 encoding for embedding in HTML
            byte[] bytes = IOUtils.toByteArray(objectDataStream);
            String base64Image = Base64.getEncoder().encodeToString(bytes);

            // Close the resources
            objectDataStream.close();

            // Return the Base64 encoded image string
            return base64Image;

        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }
	 
	 
	 
	 
	 private String parseThymeleafTemplate(PolicyDetails policyDetails) 
	 {
	        
			if (policyDetails != null) 
	        {
			
				
	        String name = policyDetails.getFirstname() + " " + policyDetails.getLastname();      
			
			Date date = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
			String dateStr = formatter.format(date);
		
			String imageData = null;
			String imageDataFoot = null;
            String templateContent = null;
            		
			System.out.println("Got template");
			
	        try {
	        	
	        	templateContent=fetchTemplateFromS3("OldLetterTemplate.html");
	        	System.out.println("Templated loaded succesfully");
	                
	            imageData=fetchImageFromS3("letterheadernew.jpg");
	            System.out.println("Got Header");
	            imageDataFoot=fetchImageFromS3("letterfooter_new.jpg");
	            System.out.println("Got Footer");
	            if (templateContent == null) 
	            {
	            	 s+="  Default HTML content  ";
	                return "Default HTML content";
	            }
	            
	            
	     
            try {
            StringTemplateResolver templateResolver = new StringTemplateResolver();
            templateResolver.setTemplateMode(TemplateMode.HTML);

            TemplateEngine templateEngine = new TemplateEngine();
            templateEngine.setTemplateResolver(templateResolver);
            Context context = new Context();
	           
	            
	            
//	            s+="  setting context  ";
	            
			context.setVariable("LetterDate", dateStr);
			context.setVariable("NAME", name);
			context.setVariable("ADDRESS1", policyDetails.getAddress1());
			context.setVariable("ADDRESS2", policyDetails.getAddress2());
			context.setVariable("ADDRESS3", policyDetails.getAddress2());
			context.setVariable("PolicyNo", policyDetails.getPolicyno());
			
//			
			context.setVariable("base64Image", imageData);
//			System.out.println("Loaded image header");
//			System.out.println(imageData);
			context.setVariable("base64ImageFoot", imageDataFoot);
//			System.out.println("Loaded image footer");

					String html="";

					try {
					    html = templateEngine.process(templateContent, context);
					} catch (Exception e) {
					    // Log the exception details along with context information
					    System.out.println("Error processing template: " + e.getMessage());
					    System.out.println("Template Content: " + templateContent);
					    System.out.println("Context Variables: " + context);
					    // You can also rethrow the exception if needed
					    throw e;
					}

					return html;
	        
	        
            }catch(Exception e)
            {
            	System.out.println(e.getMessage());
            }
	        }catch(Exception e)
            {
            	System.out.println(e.getMessage());
            }
	        }
			        return "Default HTML content"; // or throw new IllegalStateException("No policy details found for the given policy number");
			}


	
		 
		 
		 public byte[] generatePdfFromHtml(String html, String policyNo) throws IOException, DocumentException {
			 
			 System.out.println("Into Genration");
			 if (html == null ) 
			 	{ //|| html.trim().isEmpty()) {
				    // Handle the case where HTML content is null or empty
				    throw new IllegalArgumentException("HTML content is null or empty");
				}
			 
			 	
			    ITextRenderer renderer = new ITextRenderer();
			    renderer.setDocumentFromString(html);
			    renderer.layout();

			    try (ByteArrayOutputStream os = new ByteArrayOutputStream()) {
			        renderer.createPDF(os);
			        os.close();
			        
			        System.out.println("Generation completed");
			        return os.toByteArray();
			    } catch (DocumentException | IOException e) {
			        e.printStackTrace();
			        throw e;
			    }
			}

		 
		 public void uploadFileToS3(byte[] pdfContent,String policyno) {
		        try {
		            InputStream inputStream = new ByteArrayInputStream(pdfContent);

		            // Specify the object key
		            String path = "pdf/";
		            String timestamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		            String key = policyno + "_generated_" + timestamp + ".pdf";
		            key = path + key;
		            // Upload the file to S3
		            amazonS3Client.putObject(PutObjectRequest.builder()
		                    .bucket(bucketName)
		                    .key(key)
		                    .build(), RequestBody.fromInputStream(inputStream, pdfContent.length));
		        } catch (Exception e) {
		            // Handle the exception as needed
		            e.printStackTrace();
		            throw new RuntimeException("Error uploading file to S3: " + e.getMessage());
		        }
		    }
		 
		 
		 
		 
		 
		 //For Local
		/* 
		 public String fetchImageBase64(String imageName) {
		        try {
		            // Load image from the classpath (assuming it's in /static/images)
		            ClassPathResource classPathResource = new ClassPathResource("static/images/" + imageName);
		            
		            // Convert InputStream to Base64 encoding for embedding in HTML
		            byte[] bytes = IOUtils.toByteArray(classPathResource.getInputStream());
		            String base64Image = Base64.getEncoder().encodeToString(bytes);

		            // Return the Base64 encoded image string
		            return base64Image;
		            
		        } catch (IOException e) {
		            e.printStackTrace();
		            // Handle exceptions or log errors
		            return ""; // Return an empty string or handle errors as needed
		        }
		    }
		 
		 private String loadTemplate(String templatePath) {
		        try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream(templatePath);
		             InputStreamReader streamReader = new InputStreamReader(inputStream, StandardCharsets.UTF_8);
		             BufferedReader reader = new BufferedReader(streamReader)) {

		            StringBuilder templateContent = new StringBuilder();
		            String line;
		            while ((line = reader.readLine()) != null) {
		            	templateContent.append(line);
			        }

			        // Close the resources
			        reader.close();
			        streamReader.close();
			        inputStream.close();
		            	
		            System.out.println("TEMPLATE Loaded");
		            return templateContent.toString();

		        } catch (IOException e) {
		            e.printStackTrace();
		            // Handle template loading exceptions
		            return null;
		        }
		    }

		*/

		

}
